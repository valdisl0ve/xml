﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ConsoleApp18
{
    [Serializable]
    public class Buyer
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public int Id { get; set; }
        
        [BsonElement("BuyerName")]
        [BsonIgnoreIfNull]
        public string BuyerName { get; set; }
        
        [BsonElement("BuyerPhone")]
        [BsonIgnoreIfNull]
        public string BuyerPhone { get; set; }
        
        
      
        
       
        public Buyer( string buyerName, string buyerPhone)
        {
            BuyerName = buyerName;
            BuyerPhone = buyerPhone;
        }
    }
}