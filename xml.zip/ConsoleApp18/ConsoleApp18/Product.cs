﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ConsoleApp18
{
    public class Product
    {
        
        
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public int Id { get; set; }
        
        [BsonElement("ProductName")]
        [BsonIgnoreIfNull]
        public string ProductName { get; set; }
        
        [BsonElement("ProductRemainder")]
        [BsonIgnoreIfNull]
        public int ProductRemainder { get; set; }
        
        [BsonElement("ProductPrice")]
        [BsonIgnoreIfNull]
        public int ProductPrice { get; set; }
        
        public Product( string productName, int productRemainder, int productPrice)
        {
            ProductName = productName;
            ProductRemainder = productRemainder;
            ProductPrice = productPrice;
        }
    }
}