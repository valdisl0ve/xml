﻿using System;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using ConsoleApp18;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using static System.Console;
using MongoDB.Driver;

namespace ConsoleApp3
{
   

class Program
    {
        static void Main(string[] args)
        {
          
            string connection_string = "mongodb://localhost";
            var db = new MongoClient(connection_string);
            var dbList = db.ListDatabases().ToList();
            var test = db.GetDatabase("local");
            var buyer = test.GetCollection<Buyer>("Buyer");
            var filter = new BsonDocument();
            var documents = buyer.Find(filter).ToList();

           
        
            
            

            var xml = new XmlSerializer(typeof(Buyer));
            using var file = new FileStream("student.xml", FileMode.OpenOrCreate);
            xml.Serialize(file, buyer);
            
               
                
        }
    }
}












/*
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ConsoleApp18;
using MongoDB.Bson;
using MongoDB.Driver;

class Program
{
    static void Main(string[] args)
    {
        FindDocs().GetAwaiter().GetResult();
 
        Console.ReadLine();
    }
    private static async Task FindDocs()
    {
        string connectionString = "mongodb://localhost";
        var client = new MongoClient(connectionString);
        var database = client.GetDatabase("local");
        var collection = database.GetCollection<BsonDocument>("Buyer");
        var filter = new BsonDocument();




        string tmp = "";
        
        
        using (var cursor = await collection.FindAsync(filter))
        {
            while (await cursor.MoveNextAsync())
            {
                var something = cursor.Current;
                foreach (var doc in something)
                {
                    Console.WriteLine(doc);
                   tmp = tmp + doc;
                }
            }
        }
        
        
        File.WriteAllText("myFile.xml",tmp);
        
        
    }
}
*/