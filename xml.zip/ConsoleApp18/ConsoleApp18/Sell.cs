﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ConsoleApp18
{
    public class Sell
    {
        
        
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public int Id { get; set; }
        
        [BsonElement("WhoBuyer")]
        [BsonIgnoreIfNull]
        public string WhoBuyer { get; set; }
        
        [BsonElement("WhatSold")]
        [BsonIgnoreIfNull]
        public string WhatSold { get; set; }
        
        [BsonElement("Value")]
        [BsonIgnoreIfNull]
        public int Value { get; set; }
        
        [BsonElement("Sum")]
        [BsonIgnoreIfNull]
        public int Sum { get; set; }
        
        [BsonElement("Date")]
        [BsonIgnoreIfNull]
        public string Date { get; set; }
        
        
        public Sell( string whoBuyer, string whatSold, int value, int sum, string date)
        {
            WhoBuyer = whoBuyer;
            WhatSold = whatSold;
            Value = value;
            Sum = sum;
            Date = date;
        }
        
        
    }
}